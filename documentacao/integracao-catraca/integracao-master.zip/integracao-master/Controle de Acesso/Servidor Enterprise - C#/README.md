## Descrição

Exemplo simples de aplicação da API iD Access REST, da Control iD, em C#.

## Notas

* Para o funcionamento das opções contidas no código, primeiramente deve-se registrar o servidor por meio da opção Cadastros -> Terminal.

    * Esse processo deve ser feito sempre que o exemplo for aberto.

* Caso ocorra o seguinte erro durante o registro do terminal, o código deverá ser executado com permissões de administrador.

    > HTTP could not register URL [...]. Your process does not have access rights to this namespace.
