﻿Module Module1

    Sub Main()

        'Exemplo de programa console em VB.Net

        'Usuario.Add_users()
        'Config.Edit_company()
        'Config.Set_date_time()
        'Config.Set_daylight_time()
        'Config.Get_afd()
        'Conexao.ConectaRep_iDClass()
        Config.Get_company()

    End Sub

End Module
