# Exemplo de uso de Leitor de Mesa

Projeto utilizando o leitor de Mesa Futronic FS80.

Inclui leitura da digital e extração de templates.

### *** ATENÇÃO ***

A extração de templates funciona somente no REP iDClass e os equipamentos da linha Acesso. Por usar a API REST, portanto não funciona no iDX.
