#pragma once

#pragma region Includes
#include <ole2.h>	// OLE2 Definitions
#pragma endregion

DWORD WINAPI TesteRepCid(LPVOID lpParam);
