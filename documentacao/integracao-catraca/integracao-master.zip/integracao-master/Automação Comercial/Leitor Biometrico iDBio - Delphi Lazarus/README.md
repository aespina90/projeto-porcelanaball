# Exemplo Integracao iDBio Freepascal Lazarus Multiplataforma

## Passo a passo para execução do teste em ambiente Windows:

### Passo 1) Baixar a IDE do link: https://www.lazarus-ide.org/
### Passo 2) Copiar o arquivo libcidbio.dll contido na pasta win64 para dentro da pasta do projeto.


