#!/bin/bash

cp ../../bin_win32/libcidbio.dll . 
