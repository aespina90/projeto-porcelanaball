# Repositório de exemplos de uso da API do iDAccess

* [Acesse a WIKI para mais informações](https://github.com/controlid/iDAccess/wiki)
* [Leia a documentação da API](https://www.controlid.com.br/suporte/api_idaccess_V2.6.8.html)


