﻿namespace ControliD
{
    public enum ErroCodes
    {
        Generic,
        Reflection,
        JsonCommand,
        LoginRequestFields,
        LoginInvalid
    }
}
