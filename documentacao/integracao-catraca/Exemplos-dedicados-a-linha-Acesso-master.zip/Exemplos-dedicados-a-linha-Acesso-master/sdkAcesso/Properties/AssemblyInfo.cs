﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("SDK Acesso Control iD")]
[assembly: AssemblyDescription("SDK iDAccess")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Control iD")]
[assembly: AssemblyProduct("sdkAcesso")]
[assembly: AssemblyCopyright("Copyright © 2015-2017")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("783a6376-dc77-4d35-adea-4e3165f28445")]
[assembly: AssemblyVersion("1.17.5.25")]
[assembly: AssemblyFileVersion("1.17.5.25")]