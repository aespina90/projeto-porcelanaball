﻿namespace UnitTestAcesso
{
    public partial class BaseTest
    {
        public static string URL = "http://192.168.0.91/";
        public static string Login = "admin";
        public static string Password = "admin";
        public static int Port = 80;
    }
}