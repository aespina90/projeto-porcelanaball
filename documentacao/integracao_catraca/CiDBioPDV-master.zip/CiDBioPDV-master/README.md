# CiDBioPDV
Um simple PDV em Delphi com integração com iDBio e impressora não fiscal
